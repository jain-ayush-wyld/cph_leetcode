// popup.js - Add error handling
document.getElementById('captureUrl').addEventListener('click', () => {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const url = tabs[0].url;
      
      fetch('http://localhost:8080/receive-url', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url: url })
      })
      .then(response => response.json())
      .then(data => {
        console.log('Success:', data);
        // Optional: Show success message in popup
        document.getElementById('status').textContent = 'URL Sent Successfully!';
      })
      .catch(error => {
        console.error('Error:', error);
        // Show error in popup
        document.getElementById('status').textContent = 'Failed to send URL';
      });
    });
  });